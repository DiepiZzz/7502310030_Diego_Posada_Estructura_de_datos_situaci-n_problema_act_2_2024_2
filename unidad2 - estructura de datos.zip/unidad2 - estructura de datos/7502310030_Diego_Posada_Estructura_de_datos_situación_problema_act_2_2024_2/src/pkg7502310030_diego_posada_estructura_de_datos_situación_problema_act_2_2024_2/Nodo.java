
package pkg7502310030_diego_posada_estructura_de_datos_situación_problema_act_2_2024_2;


public class Nodo {
    
    Producto prod;
    Nodo sig;

    public Nodo(Producto prod) {
        this.prod = prod;
        this.sig = null;
    }
  
    
}
