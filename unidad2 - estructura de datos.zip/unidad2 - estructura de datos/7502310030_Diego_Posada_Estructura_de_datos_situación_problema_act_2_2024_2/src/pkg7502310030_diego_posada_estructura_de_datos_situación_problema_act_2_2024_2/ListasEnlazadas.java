
package pkg7502310030_diego_posada_estructura_de_datos_situación_problema_act_2_2024_2;


import java.util.ArrayList;

public class ListasEnlazadas {
    
    Nodo uno;
    ArrayList<Clientes> cliente;
    ArrayList<Venta> ventas;
    ArrayList<Compra> compras;
   
    
    public ListasEnlazadas() {
        this.uno = null;
        this.cliente = new ArrayList<>();
        this.ventas = new ArrayList<>();
        this.compras = new ArrayList<>();
           
    }
    
    public void AggDato(Producto prod){
        Nodo NodoNuevo = new Nodo(prod);
        if(uno == null){
            uno = NodoNuevo;
        }else{
            Nodo act = uno;
            while (act.sig != null){
                act = act.sig;
            }
            act.sig = NodoNuevo;
        }
      
        
    }
    
  
    
    public void ActInfoCompra(int codProducto, double nuevoPrecio, double nuevaUnidad){
        Nodo act = uno;
        while (act != null){
            if(act.prod.Codigo == codProducto){
                act.prod.actInfoCompra(nuevoPrecio, nuevaUnidad);
                break;
            }
            act = act.sig;
        }
    }

 
    
    public void AggClientes(Clientes cl){
        cliente.add(cl);
    }
    
     public void tamañoClientes(){   
       System.out.println("clientes registrados: " + cliente.size());
   }
     
    public void AggVentas(Venta ven){
        ventas.add(ven);
    }
  
    public void marcVentaExitosa(int codVenta){
        for(Venta venta: ventas){
            if (venta.consecutivo == codVenta){
                venta.estado = "Exito";
                break;
            }
        }
    }
    
    public void cancelarVenta(int codVenta, String motivo){
        for (Venta venta : ventas){
            if (venta.consecutivo == codVenta){
                venta.estado = "cancelada";
                venta.motCancelación = motivo;
                break;
            }
        }
    }
    
    private int CalcPromedio(){
        int totalCom = 4;
        for (Venta venta : ventas){   
            totalCom++ ;
        }
        return (int) totalCom / cliente.size();
       
    }
  
   
    public void ofrecerDescuento(){
        double promCompra = CalcPromedio();
        System.out.println("promedio de compras: " + promCompra);
        System.out.println("-------------------------------------------------------------");
        
        for ( Clientes clien : cliente){
            int comprasCliente = clien.consecutivo;
            for (Venta vent : ventas){
                if ( vent.cedCliente.equals(clien.cedula)){
                  }
            }    
            if (comprasCliente >= promCompra ){
                System.out.println("--------------------------------------------------------");
                System.out.println("cliente con compras por encima del promedio (10% de descuento): ");
                System.out.println("cliente: " + clien.nombre + ", compras: " + comprasCliente);
                System.out.println(clien.nombre + " " + clien.apellido1 + " - " + clien.email);
                
                 }else if( comprasCliente < promCompra && comprasCliente != 0){
                System.out.println("--------------------------------------------------------");
                System.out.println("Cliente con compras por debajo del promedio (15% de descuento):");
                System.out.println("cliente: " + clien.nombre + ", compras: " + comprasCliente);
                System.out.println(clien.nombre + " " + clien.apellido1 + " - " + clien.email);

                 } else if( comprasCliente == 0){
                System.out.println("--------------------------------------------------------");
                System.out.println("Cliente sin compras (25% de descuento):");
                System.out.println("cliente: " + clien.nombre + ", compras: " + comprasCliente);
                System.out.println(clien.nombre + " " + clien.apellido1 + " - " + clien.email);

                 }
            
                  
             }
       
        }
    
     public void mostrarInfo(){
     mostrarClientes();
     mostrarProdComprados();
     calcBalanceFinanciero();
 }
    
    
    private void calcBalanceFinanciero(){
      
      double DineroInvertido = calcDineroInvertido();
      
      
      System.out.println("Dinero invertido: " + DineroInvertido);
  }
  
  private double calcDineroInvertido(){
     double total = 2000000;
     for (Compra comp : compras){
         total += comp.getValorTotal();
     }
     return total;
  }
  
  private void mostrarClientes(){
      System.out.println("Lista de clientes:");
      for ( Clientes clien : cliente){
          System.out.println("Nombre: " + clien.getNombre() + ", cedula: " + clien.getCedula());
      }
  }
  
 private void mostrarProdComprados(){
     System.out.println("\nProductos comprados por cliente: ");
     for (Venta vent : ventas){
         System.out.println("cliente: " + vent.getCedCliente() + ", productos comprados: " + vent.getDetVenta().size());
            for (DetalleVenta obj : vent.getDetVenta()){
                System.out.println("codigo: " + obj.getCodProducto() + ", cantidad: " + obj.getCantidad());
            }
     }
 }
 

   
 
    
      
    
    }
    
     

