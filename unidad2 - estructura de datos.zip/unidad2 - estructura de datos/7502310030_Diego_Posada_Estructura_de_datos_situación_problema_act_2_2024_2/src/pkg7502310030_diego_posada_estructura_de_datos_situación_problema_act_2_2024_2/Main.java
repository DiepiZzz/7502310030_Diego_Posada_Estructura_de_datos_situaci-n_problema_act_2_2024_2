
package pkg7502310030_diego_posada_estructura_de_datos_situación_problema_act_2_2024_2;

import java.util.ArrayList;


public class Main {

    
    public static void main(String[] args) {
      
        ListasEnlazadas list = new ListasEnlazadas();
       
         Clientes cl1 = new Clientes("12345678","Diego","Posada","Gonzalez","Masculino","27/03/2004","3013528893","dposadag1@gmail.com","Blas de lezo","solteriño",4);
         Clientes cl2 = new Clientes("12345679","Miguel","Ricardo","Mantilla","Masculino","27/03/2004","3013528893","MiguelZzz@gmail.com","Turbaco","solteriño",1);
         Clientes cl3 = new Clientes("12345677","Carlos","Bertel","Mantilla","Masculino","27/03/2004","3013528893","CralosGei@gmail.com","Arjona","solteriño",0);

       list.AggClientes(cl1);
       list.AggClientes(cl2); 
       list.AggClientes(cl3);
        
        Producto prod1 = new Producto(1,"tal","ds","ds",32,32,32,32,"ds","ds");
        Producto prod2 = new Producto(2,"ds","ds","ds",32,32,32,32,"ds","");

        list.AggDato(prod1);
        list.AggDato(prod2);
        
        
        Compra comProd1 = new Compra(2,"rer","rer",prod1.Codigo,prod1.precioCompra,2);
                prod1.AggCompra(comProd1);
        Compra comProd2 = new Compra(2,"rere","rere",prod1.Codigo,prod1.precioCompra,2);
                prod2.AggCompra(comProd2);
            
        
        Venta vent1 = new Venta(2,"27/02/2024","12345678","efectivo","dsds"); 
        Venta vent2 = new Venta(2,"04/03/2004","12345679","tarjeta","dsds"); 
                
               list.AggVentas(vent1);
               list.AggVentas(vent2);
     
               
               
               
    list.tamañoClientes();
  
    list.ofrecerDescuento();
    
    System.out.println("----------------------------------------------------------------------------");
      
    list.mostrarInfo();
    }
    
}
