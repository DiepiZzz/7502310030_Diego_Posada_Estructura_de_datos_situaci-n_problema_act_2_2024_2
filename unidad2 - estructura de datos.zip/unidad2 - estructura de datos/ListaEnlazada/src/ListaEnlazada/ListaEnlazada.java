
package ListaEnlazada;


public class ListaEnlazada {
    Nodo inicio, fin;
    int cont = 0;
    
    public ListaEnlazada(){
        inicio = null;
        fin = null;
    }
    
    public boolean listaVacia(){
        return inicio == null;
    }    
    
    
    public void AgregarDatoInicio(String d){
        cont++;
        if (listaVacia()){
            inicio = new Nodo(d, inicio);
            fin = inicio;
            
        } else {
            inicio = new Nodo(d, inicio);
            
        }
      
    }
 
    public void mostrarLista(){
            Nodo auxiliar = inicio; 
            while (auxiliar!=null){
                System.out.println("Dato enlistado: " + auxiliar.dato);
                auxiliar = auxiliar.siguiente;
 
            
        }
            System.out.println("-------");
            
            
        }
           public void cantidadDatos(){
               System.out.println("-----");
         
               System.out.println("Cantidad de datos en lista: " + cont);
           }
           
    public void AgregarDatoFinal(String d){
               cont++;
               if(listaVacia()){
                   inicio = new Nodo(d);
                   fin = inicio;
               } else {
                   fin.siguiente= new Nodo(d);
                   fin = fin.siguiente;
                   
                   
               }
               
           }

    public String PrimerDato(){
                   return inicio.dato;
                   
               
               }
    public String UltimoDato(){
                   return fin.dato;
               }
               
    public int datoBusc(String d){
            int indice = 1;
                Nodo auxiliar = inicio;

                while(auxiliar!= null){
                    if(auxiliar.dato.equalsIgnoreCase(d)){
                    return indice;
                       }
                       
                    auxiliar = auxiliar.siguiente;
                    indice ++;
                       
                   }
                   
                return -1;
                }
               
               
    public void eliminarDato(String d){ //el dato que recibirá para eliminar será de tipo String, lógicamente
                   if (inicio == null){
                       return;
                   }
                   if(inicio.dato.equals(d)){
                       inicio = inicio.siguiente;
                       
                   if (inicio == null){
                       fin = null;
                   }
                   
                   cont--;
                   return;
                   
                   }
               
                   Nodo anterior = inicio;
                   Nodo auxiliar = inicio.siguiente;
                   while(auxiliar != null){
                       if(auxiliar.dato.equalsIgnoreCase(d)){
                           anterior.siguiente = auxiliar.siguiente;
                           if(auxiliar == fin){
                               fin = anterior;
                               
                           }
                           
                           cont--;
                           return;
                           
                       }
                       anterior = auxiliar;
                       auxiliar = auxiliar.siguiente;
                       
                       
                       
                   }
                   
                   
               }
               
               
    public void bubbleSort(){
                   boolean intercambiar;
                   do{
                       intercambiar = false;
                       Nodo act = inicio;
                       while (act != null && act.siguiente != null){
                           if(act.dato.compareTo(act.siguiente.dato) > 0){
                               String temp = act.dato;
                               act.dato = act.siguiente.dato;
                               act.siguiente.dato = temp;
                               intercambiar = true;
                               
                           }
                           act = act.siguiente;
                       }
                   }while (intercambiar);
               }
                   
    public void insertionSort(){
                   if (inicio == null || inicio.siguiente == null){
                       return;
                       }
                   
                   Nodo sort = null;
                   Nodo current = inicio;
                   
                   while (current != null){
                       Nodo next = current.siguiente;
                       sort = sortInsert(sort, current);
                       current = next;
                   }
                   
                   inicio = sort;
                   
               }
               
               Nodo sortInsert(Nodo sort, Nodo newNodo){
                   if (sort == null || sort.dato.compareTo(newNodo.dato) > 0){
                       newNodo.siguiente = sort;
                       return newNodo;
                   }
               Nodo current = sort;
               
               while (current.siguiente != null && current.siguiente.dato.compareTo(newNodo.dato) < 0){
                   current = current.siguiente;
               }
               
               newNodo.siguiente = current.siguiente;
               current.siguiente = newNodo;
               
               return sort;
               
               
}

    public void selectionSort(){
                  Nodo act = inicio;
                  while (act != null){
                      Nodo min = encontrarMin(act);
                      intercambiar(act, min);
                      act = act.siguiente;
                      
                  }
              }

        Nodo encontrarMin(Nodo inicio){
            Nodo min = inicio;
            Nodo act = inicio.siguiente;
            while (act != null){
                if (act.dato.compareTo(min.dato) < 0){
                    min = act;
                }               
               act = act.siguiente;            
            }       
             return min;  
}   
    
    private void intercambiar(Nodo nod1, Nodo nod2){
        String temp = nod1.dato;
        nod1.dato = nod2.dato;
        nod2.dato = temp;
    }
    
    
    
    
} 
