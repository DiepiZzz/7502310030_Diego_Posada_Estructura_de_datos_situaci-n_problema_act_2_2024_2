class Nodo:
    def __init__(self, dato):
        self.dato = dato
        self.siguiente = None

class ListaEnlazada:
    def __init__(self):
        self.inicio = None
        self.fin = None
        self.cont = 0

    def lista_vacia(self):
        return self.inicio is None

    def agregar_dato_inicio(self, d):
        self.cont += 1
        if self.lista_vacia():
            self.inicio = Nodo(d)
            self.fin = self.inicio
        else:
            nuevo_nodo = Nodo(d)
            nuevo_nodo.siguiente = self.inicio
            self.inicio = nuevo_nodo

    def mostrar_lista(self):
        auxiliar = self.inicio
        while auxiliar is not None:
            print("Dato enlistado:", auxiliar.dato)
            auxiliar = auxiliar.siguiente
        print("-------")

    def cantidad_datos(self):
        print("Cantidad de datos en lista:", self.cont)

    def agregar_dato_final(self, d):
        self.cont += 1
        if self.lista_vacia():
            self.inicio = Nodo(d)
            self.fin = self.inicio
        else:
            self.fin.siguiente = Nodo(d)
            self.fin = self.fin.siguiente

    def primer_dato(self):
        return self.inicio.dato if self.inicio else None

    def ultimo_dato(self):
        return self.fin.dato if self.fin else None

    def dato_busc(self, d):
        indice = 1
        auxiliar = self.inicio
        while auxiliar is not None:
            if auxiliar.dato.lower() == d.lower():
                return indice
            auxiliar = auxiliar.siguiente
            indice += 1
        return -1

    def eliminar_dato(self, d):
        if self.lista_vacia():
            return
        if self.inicio.dato.lower() == d.lower():
            self.inicio = self.inicio.siguiente
            if self.inicio is None:
                self.fin = None
            self.cont -= 1
            return

        anterior = self.inicio
        actual = self.inicio.siguiente
        while actual is not None:
            if actual.dato.lower() == d.lower():
                anterior.siguiente = actual.siguiente
                if actual == self.fin:
                    self.fin = anterior
                self.cont -= 1
                return
            anterior = actual
            actual = actual.siguiente

    def bubble_sort(self):
        intercambiar = True
        while intercambiar:
            intercambiar = False
            actual = self.inicio
            while actual is not None and actual.siguiente is not None:
                if actual.dato > actual.siguiente.dato:
                    temp = actual.dato
                    actual.dato = actual.siguiente.dato
                    actual.siguiente.dato = temp
                    intercambiar = True
                actual = actual.siguiente

    def insertion_sort(self):
        if self.inicio is None or self.inicio.siguiente is None:
            return

        sort = None
        current = self.inicio
        while current is not None:
            siguiente = current.siguiente
            sort = self.sort_insert(sort, current)
            current = siguiente
        self.inicio = sort

    def sort_insert(self, sort, new_node):
        if sort is None or sort.dato > new_node.dato:
            new_node.siguiente = sort
            return new_node

        actual = sort
        while actual.siguiente is not None and actual.siguiente.dato < new_node.dato:
            actual = actual.siguiente

        new_node.siguiente = actual.siguiente
        actual.siguiente = new_node
        return sort

    def selection_sort(self):
        actual = self.inicio
        while actual is not None:
            minimo = self.encontrar_minimo(actual)
            self.intercambiar(actual, minimo)
            actual = actual.siguiente

    def encontrar_minimo(self, inicio):
        minimo = inicio
        actual = inicio.siguiente
        while actual is not None:
            if actual.dato < minimo.dato:
                minimo = actual
            actual = actual.siguiente
        return minimo

    def intercambiar(self, nodo1, nodo2):
        temp = nodo1.dato
        nodo1.dato = nodo2.dato
        nodo2.dato = temp

    def menu(self):
        opcion = 0

        while opcion != 12:
            try:
                opcion = int(input(
                    "1- Agregar un dato al inicio\n"
                    "2- Agregar un dato al final\n"
                    "3- Buscar un elemento en la lista\n"
                    "4- Consultar primer dato de lista\n"
                    "5- Consultar último dato de lista\n"
                    "6- Eliminar elementos de la lista\n"
                    "7- Cantidad elementos en lista\n"
                    "8- Mostrar lista\n"
                    "9- Ordenar lista (bubbleSort)\n"
                    "10- Ordenar lista (insertionSort)\n"
                    "11- Ordenar lista (selectionSort)\n"
                    "12- Salir\n"
                    "Ingrese una opción: "
                ))

                if opcion == 1:
                    dato = input("Ingresa el dato: ")
                    self.agregar_dato_inicio(dato)
                elif opcion == 2:
                    dato = input("Agrega un dato al final de la lista: ")
                    self.agregar_dato_final(dato)
                elif opcion == 3:
                    buscar_dato = input("Ingresa un elemento a buscar en la lista: ")
                    ubicacion = self.dato_busc(buscar_dato)
                    if ubicacion != -1:
                        print("Dato encontrado en la ubicación:", ubicacion)
                    else:
                        print("Dato no encontrado")
                elif opcion == 4:
                    print("Primer elemento en lista:", self.primer_dato())
                elif opcion == 5:
                    print("Último dato en lista:", self.ultimo_dato())
                elif opcion == 6:
                    dato_eliminar = input("Ingresa un dato para eliminar: ")
                    self.eliminar_dato(dato_eliminar)
                elif opcion == 7:
                    self.cantidad_datos()
                elif opcion == 8:
                    self.mostrar_lista()
                elif opcion == 9:
                    self.bubble_sort()
                elif opcion == 10:
                    self.insertion_sort()
                elif opcion == 11:
                    self.selection_sort()
                elif opcion == 12:
                    break
                else:
                    print("Opción inválida. Intente de nuevo.")

            except ValueError:
                print("Por favor, ingrese un número.")

if __name__ == "__main__":
    lista = ListaEnlazada()
    lista.menu()
