
package pkg7502310030_diego_posada_estructura_de_datos_act_2_2024_1;


public class Bubblesort {

    
    public static void main(String[] args) {
     int[] lista = {5,2,3,4,5,6,7,8,9};
     bubbleSort(lista);
        System.out.println("lista ordenada: ");
        for(int i : lista){
            System.out.println(i + "");
        }
    }

    private static void bubbleSort(int[] lista) {
         int n = lista.length;
        for(int i = 0; i < n-1; i++){
            for(int j = 0; j < n-i-1; j++){
                if(lista[j] > lista[j+1]){
                   int temp = lista[j];
                   lista[j] = lista[j+1];
                   lista[j+1] = temp;
                }
            }

        }
    }
    }

