
package ListaEnlazada;




import javax.swing.JOptionPane;
public class Main {

   
    public static void main(String[] args) {
       
                                                                                                 

        int opcion = 0;
        ListaEnlazada lista = new ListaEnlazada();
        
        do
        {
            
            try
            {
             opcion=Integer.parseInt(JOptionPane.showInputDialog(null, ""
             + "1- Agregar un dato al inicio" + "\n" +
             "2- Agregar un dato al final" + "\n" + 
             "3- Busca un elemento en la lista" + "\n" +
             "4- Consultar primer dato de lista" + "\n" + 
             "5- Consultar último dato de lista" + "\n" +
             "6- Eliminar elementos de la lista" + "\n" +
             "7- Cantidad elementos en lista" + "\n" +
             "8- Mostrar lista" + "\n" +   
             "9- Ordenar lista (bubbleSort)" + "\n" + 
             "10- Ordenar lista (insertionSort" + "\n" +
             "11- Ordenar  lista (selectionSort)" + "\n" +
             "12- Salir"
             ));
             
              
             switch (opcion){
                 case 1: 
                     String dato = JOptionPane.showInputDialog(null, "Ingresa el dato");
                     lista.AgregarDatoInicio(dato);
                 break;
                 
                 case 2:
                     dato = JOptionPane.showInputDialog(null, "Agrega un dato al final de la lista");
                     lista.AgregarDatoFinal(dato);
                     break;
                 case 3:
                     String buscarDato = JOptionPane.showInputDialog(null, "Ingresa un elemento a buscar en la lista");
                     int ubicacion = lista.datoBusc(buscarDato);
                     if(ubicacion != -1){
                         JOptionPane.showMessageDialog(null, "Dato encontrado en la ubicacion: " + ubicacion);
                     }
                     else {
                         JOptionPane.showMessageDialog(null, "Dato no encontrado");
                     }
                     break;
                     
                 case 4:
                     JOptionPane.showMessageDialog(null, "Primer elemento en lista: " + lista.PrimerDato());
                     break;
                 case 5:
                     JOptionPane.showMessageDialog(null, "Último dato en lista: " + lista.UltimoDato());
                     break;
                 case 6:
                     String datoEliminar = JOptionPane.showInputDialog(null, "Ingresa un dato para eliminar");
                     lista.eliminarDato(datoEliminar);
                     break;
                 case 7:
                     lista.cantidadDatos();
                 break;
                 
                 case 8:
                 lista.mostrarLista();
                  break;
                  
                 case 9:
                 lista.bubbleSort();
                 
                 case 10:
                 lista.insertionSort();
                 
                 
                 case 11:
                 lista.selectionSort();
                 
                 case 12:
                 break;
    
                     
             } 
 
                              
            } catch(NumberFormatException e){
                System.out.println("Ingresa un numero del 1 al 12 para acceder a las distintas funciones de la lista");
            }
            
            
        } while(opcion!= 12);


        
        }
    }
    


