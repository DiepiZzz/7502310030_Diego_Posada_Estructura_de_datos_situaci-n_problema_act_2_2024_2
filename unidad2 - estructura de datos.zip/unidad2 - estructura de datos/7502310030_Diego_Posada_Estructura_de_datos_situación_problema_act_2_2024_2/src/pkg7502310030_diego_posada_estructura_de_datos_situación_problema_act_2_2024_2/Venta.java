
package pkg7502310030_diego_posada_estructura_de_datos_situación_problema_act_2_2024_2;

import java.util.ArrayList;

public class Venta {
    
    int consecutivo;
    String fecha;
    String cedCliente;
    String medPago;
    String modalidad;
    String estado;
    String motCancelación;
    ArrayList<DetalleVenta> detVenta;

    public Venta(int consecutivo, String fecha, String cedCliente, String medPago, String modalidad) {
        this.consecutivo = consecutivo;
        this.fecha = fecha;
        this.cedCliente = cedCliente;
        this.medPago = medPago;
        this.modalidad = modalidad;
        this.estado = estado;
        this.motCancelación = motCancelación;
        this.detVenta = detVenta = new ArrayList<>();
    }

    public int getConsecutivo() {
        return consecutivo;
    }

    public void setConsecutivo(int consecutivo) {
        this.consecutivo = consecutivo;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getCedCliente() {
        return cedCliente;
    }

    public void setCedCliente(String cedCliente) {
        this.cedCliente = cedCliente;
    }

    public String getMedPago() {
        return medPago;
    }

    public void setMedPago(String medPago) {
        this.medPago = medPago;
    }

    public String getModalidad() {
        return modalidad;
    }

    public void setModalidad(String modalidad) {
        this.modalidad = modalidad;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getMotCancelación() {
        return motCancelación;
    }

    public void setMotCancelación(String motCancelación) {
        this.motCancelación = motCancelación;
    }

    public ArrayList<DetalleVenta> getDetVenta() {
        return detVenta;
    }

    public void setDetVenta(ArrayList<DetalleVenta> detVenta) {
        this.detVenta = detVenta;
    }

   

   
   
   

   
    
    
    
    
}
