
package pkg7502310030_diego_posada_estructura_de_datos_situación_problema_act_2_2024_2;

import java.util.ArrayList;


public class Producto {
    
    int Codigo;
    String Nombre;
    String Marca;
    String Color;
    double precioCompra;
    double precioVenta;
    double porcDeDescuento;
    int unidExistentes;
    String medidas;
    String categoría;
    ArrayList<Compra> compras;
    

    public Producto(int Codigo, String Nombre, String Marca, String Color, double precioCompra, double precioVenta, double porcDeDescuento, int unidExistentes, String medidas, String categoría) {
        this.Codigo = Codigo;
        this.Nombre = Nombre;
        this.Marca = Marca;
        this.Color = Color;
        this.precioCompra = precioCompra;
        this.precioVenta = precioVenta;
        this.porcDeDescuento = porcDeDescuento;
        this.unidExistentes = unidExistentes;
        this.medidas = medidas;
        this.categoría = categoría;
        this.compras = new ArrayList<>();
    }

 public void AggCompra(Compra com){
     compras.add(com);
 }   
 
 
    
       public void actInfoCompra(double nuevoPrecio, double nuevaUnidad){
           this.precioCompra = nuevoPrecio;
           this.precioVenta = nuevoPrecio * 1.4;
           this.unidExistentes += nuevaUnidad;
          
       }   
    
  
}
