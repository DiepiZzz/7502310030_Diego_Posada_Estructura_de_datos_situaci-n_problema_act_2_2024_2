
package pkg7502310030_diego_posada_estructura_de_datos_situación_problema_act_2_2024_2;

public class DetalleVenta {
    
    int codProducto;
    double precioVenta;
    double cantidad;
    double valorDescuento;
    double valorNoIva;
    double valorDescuentoApl;
    double valorIva;
    double valorTotal;

    public DetalleVenta(int codProducto, double precioVenta, double cantidad, double valorDescuento) {
        this.codProducto = codProducto;
        this.precioVenta = precioVenta;
        this.cantidad = cantidad;
        this.valorDescuento = valorDescuento;
        CalcValores();
    }

    
    
    private void CalcValores(){
        valorNoIva = precioVenta * cantidad;
        valorDescuentoApl = valorNoIva * (valorDescuento / 100);
        valorIva = (valorNoIva - valorDescuentoApl) * 0.19;
        valorTotal = valorNoIva - valorDescuentoApl + valorIva;
    }

    public int getCodProducto() {
        return codProducto;
    }

    public void setCodProducto(int codProducto) {
        this.codProducto = codProducto;
    }

    public double getPrecioVenta() {
        return precioVenta;
    }

    public void setPrecioVenta(double precioVenta) {
        this.precioVenta = precioVenta;
    }

    public double getCantidad() {
        return cantidad;
    }

    public void setCantidad(double cantidad) {
        this.cantidad = cantidad;
    }

    public double getValorDescuento() {
        return valorDescuento;
    }

    public void setValorDescuento(double valorDescuento) {
        this.valorDescuento = valorDescuento;
    }

    public double getValorNoIva() {
        return valorNoIva;
    }

    public void setValorNoIva(double valorNoIva) {
        this.valorNoIva = valorNoIva;
    }

    public double getValorDescuentoApl() {
        return valorDescuentoApl;
    }

    public void setValorDescuentoApl(double valorDescuentoApl) {
        this.valorDescuentoApl = valorDescuentoApl;
    }

    public double getValorIva() {
        return valorIva;
    }

    public void setValorIva(double valorIva) {
        this.valorIva = valorIva;
    }

    public double getValorTotal() {
        return valorTotal;
    }

    public void setValorTotal(double valorTotal) {
        this.valorTotal = valorTotal;
    }
            
    
    
}
