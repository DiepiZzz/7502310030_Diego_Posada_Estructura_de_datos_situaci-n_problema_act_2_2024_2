
package pkg7502310030_diego_posada_estructura_de_datos_situación_problema_act_2_2024_2;


public class Compra {
    
    int consecutivo;
    String fecha;
    String proveedor;
    int codProducto;
    double precioCompra;
    double cantidad;
    double valorNoIva;
    double valorIva;
    double valorTotal;
    
    public Compra(int consecutivo, String fecha, String proveedor, int codProducto, double precioCompra, int cantidad) {
        this.consecutivo = consecutivo;
        this.fecha = fecha;
        this.proveedor = proveedor;
        this.codProducto = codProducto;
        this.precioCompra = precioCompra;
        this.cantidad = cantidad;
        CalcValores();

    }

    public int getConsecutivo() {
        return consecutivo;
    }

    public void setConsecutivo(int consecutivo) {
        this.consecutivo = consecutivo;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getProveedor() {
        return proveedor;
    }

    public void setProveedor(String proveedor) {
        this.proveedor = proveedor;
    }

    public int getCodProducto() {
        return codProducto;
    }

    public void setCodProducto(int codProducto) {
        this.codProducto = codProducto;
    }

    public double getPrecioCompra() {
        return precioCompra;
    }

    public void setPrecioCompra(double precioCompra) {
        this.precioCompra = precioCompra;
    }

    public double getCantidad() {
        return cantidad;
    }

    public void setCantidad(double cantidad) {
        this.cantidad = cantidad;
    }

    public double getValorNoIva() {
        return valorNoIva;
    }

    public void setValorNoIva(double valorNoIva) {
        this.valorNoIva = valorNoIva;
    }

    public double getValorIva() {
        return valorIva;
    }

    public void setValorIva(double valorIva) {
        this.valorIva = valorIva;
    }

    public double getValorTotal() {
        return valorTotal;
    }

    public void setValorTotal(double valorTotal) {
        this.valorTotal = valorTotal;
    }

    
    
                              
    private void CalcValores(){
        valorNoIva = precioCompra * cantidad;
        valorIva = valorNoIva * 0.19;
        valorTotal = valorNoIva + valorIva;
    }
    
    
    
    
    
}
