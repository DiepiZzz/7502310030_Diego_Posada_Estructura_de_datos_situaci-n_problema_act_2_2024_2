
package pkg7502310030_diego_posada_estructura_de_datos_act_2_2024_1;


public class CountingSort {

    public static void countingSort(int[] arr) {
        int n = arr.length;
        int max = getMax(arr);
        int[] count = new int[max + 1];
        int[] output = new int[n];
        for (int value : arr) {
            count[value]++;
        }
        for (int i = 1; i <= max; ++i) {
            count[i] += count[i - 1];
        }
        for (int i = n - 1; i >= 0; i--) {
            output[count[arr[i]] - 1] = arr[i];
            count[arr[i]]--;
        }
        System.arraycopy(output, 0, arr, 0, n);
    }


    private static int getMax(int[] arr) {
        int max = arr[0];
        for (int value : arr) {
            if (value > max) {
                max = value;
            }
        }
        return max;
    }

    public static void main(String[] args) {
      int[]arr = {4,6,7,4,1,2,3,5,2,4};
      countingSort(arr);
        System.out.println("Lista ordenada: ");
        for ( int i : arr){
            System.out.println(i + "");
        }
    }
    
}
